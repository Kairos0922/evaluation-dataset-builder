#!/usr/bin/env python3
"""Execute one Builder-produced webapp-testing case in an isolated DSH workspace.

This runner is an execution harness, not an evaluator. It never reads the case's
expected_behavior, forbidden_behavior, grading, or reference_outcome when
building the prompt. Independent adjudication happens after this process exits.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import signal
import socket
import subprocess
import sys
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

RUNNER_VERSION = "0.2.0"
LOOPBACK_HOSTS = {"127.0.0.1", "localhost"}
EXPECTED_PORT = 4173


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def tree_sha256(root: Path) -> str:
    hasher = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        relative = path.relative_to(root).as_posix().encode("utf-8")
        hasher.update(relative + b"\0" + bytes.fromhex(sha256_file(path)))
    return hasher.hexdigest()


def port_is_open(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.25)
        try:
            sock.connect((host, port))
            return True
        except OSError:
            return False


def http_json(url: str, method: str = "GET", payload: dict[str, Any] | None = None):
    body = None if payload is None else json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=body,
        method=method,
        headers={"Content-Type": "application/json", "Cache-Control": "no-store"},
    )
    with urllib.request.urlopen(request, timeout=5) as response:
        raw = response.read()
        try:
            decoded = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            decoded = raw.decode("utf-8", errors="replace")
        return response.status, decoded


def wait_for_health(base_url: str, timeout_seconds: int = 30) -> dict[str, Any]:
    deadline = time.monotonic() + timeout_seconds
    last_error = "not ready"
    while time.monotonic() < deadline:
        try:
            status, payload = http_json(base_url + "/api/health")
            if status == 200 and isinstance(payload, dict) and payload.get("status") == "ok":
                return payload
            last_error = f"unexpected health response: {status} {payload!r}"
        except Exception as exc:  # startup race is expected while polling
            last_error = f"{type(exc).__name__}: {exc}"
        time.sleep(0.25)
    raise TimeoutError(f"application health check timed out: {last_error}")


def stop_process_group(process: subprocess.Popen | None) -> None:
    if process is None or process.poll() is not None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait(timeout=5)


def force_close_test_port(port: int) -> bool:
    """Best-effort cleanup for a local fixture process started by the Skill."""
    fuser = shutil.which("fuser")
    if not fuser:
        return not port_is_open("127.0.0.1", port)
    subprocess.run(
        [fuser, "-k", f"{port}/tcp"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
    )
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        if not port_is_open("127.0.0.1", port):
            return True
        time.sleep(0.2)
    return not port_is_open("127.0.0.1", port)


def parse_dsh_events(path: Path) -> dict[str, Any]:
    events: list[dict[str, Any]] = []
    malformed_lines = 0
    if path.exists():
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            if not line.strip():
                continue
            try:
                item = json.loads(line)
                if isinstance(item, dict):
                    events.append(item)
            except json.JSONDecodeError:
                malformed_lines += 1

    skill_calls = [
        item for item in events
        if item.get("type") == "tool_call"
        and item.get("tool") == "skill"
        and (item.get("input") or {}).get("name") == "webapp-testing"
    ]
    results_by_call_id = {
        item.get("callId"): item
        for item in events
        if item.get("type") == "tool_result" and item.get("callId")
    }
    completed_calls = sum(
        results_by_call_id.get(call.get("callId"), {}).get("status") == "completed"
        for call in skill_calls
    )
    final_events = [item for item in events if item.get("type") == "final"]
    final_reason = None
    if final_events:
        reason = final_events[-1].get("reason") or {}
        if isinstance(reason, dict):
            final_reason = reason.get("kind")
    usage_events = [
        item.get("usage") or {}
        for item in events
        if item.get("type") == "status" and isinstance(item.get("usage"), dict)
    ]
    return {
        "event_count": len(events),
        "malformed_json_lines": malformed_lines,
        "webapp_testing_skill_calls": len(skill_calls),
        "completed_webapp_testing_skill_calls": completed_calls,
        "final_reason": final_reason,
        "total_tokens_reported": sum(
            int(item.get("totalTokens", 0) or 0) for item in usage_events
        ),
        "session_ids": [
            item.get("sessionId") for item in events
            if item.get("type") == "session" and item.get("sessionId")
        ],
    }


def require_local_target(user_input: dict[str, Any], environment: dict[str, Any]) -> tuple[str, str, int]:
    target = user_input.get("target_url") or environment.get("app_url")
    if not isinstance(target, str) or not target.strip():
        raise ValueError("case does not declare a target_url/app_url")
    parsed = urlparse(target)
    host = parsed.hostname or ""
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    if parsed.scheme != "http" or host not in LOOPBACK_HOSTS or port != EXPECTED_PORT:
        raise ValueError(f"only http://127.0.0.1:{EXPECTED_PORT} is allowed, got {target!r}")
    return target.rstrip("/"), host, port


def validate_case(case: dict[str, Any], dataset_id: str) -> None:
    if case.get("dataset_id") != dataset_id:
        raise ValueError(f"dataset_id mismatch for {case.get('case_id')}")
    user_input = case.get("user_input")
    if not isinstance(user_input, dict) or not isinstance(user_input.get("task"), str):
        raise ValueError(f"{case.get('case_id')} has no user_input.task")
    if not user_input["task"].strip():
        raise ValueError(f"{case.get('case_id')} user_input.task is empty")
    execution = case.get("execution_requirements")
    if not isinstance(execution, dict):
        raise ValueError(f"{case.get('case_id')} has no execution_requirements")
    environment = execution.get("environment")
    if not isinstance(environment, dict):
        raise ValueError(f"{case.get('case_id')} has no execution_requirements.environment")
    profile = environment.get("fixture_profile")
    if profile not in {"clean", "mutant"}:
        raise ValueError(f"unsupported fixture_profile for {case.get('case_id')}: {profile!r}")
    mutations = environment.get("fixture_mutations", [])
    if not isinstance(mutations, list) or any(not isinstance(x, str) for x in mutations):
        raise ValueError(f"invalid fixture_mutations for {case.get('case_id')}")
    allowed_mutations = {"search-case-sensitive", "stale-summary", "blank-title"}
    unknown_mutations = sorted(set(mutations) - allowed_mutations)
    if unknown_mutations:
        raise ValueError(f"unknown fixture mutations for {case.get('case_id')}: {unknown_mutations}")
    if profile == "clean" and mutations:
        raise ValueError(f"clean profile must not enable mutations for {case.get('case_id')}")
    start_state = environment.get("server_state_at_start", "running")
    if start_state not in {"running", "stopped"}:
        raise ValueError(f"unsupported server_state_at_start for {case.get('case_id')}: {start_state!r}")
    require_local_target(user_input, environment)


def build_task_prompt(case: dict[str, Any], skill_commit: str) -> str:
    """Expose only Builder-authored user_input plus public operating instructions."""
    user_input = case["user_input"]
    task = user_input["task"].strip()
    task_id = case["case_id"]
    dataset_id = case["dataset_id"]
    report_requirements = user_input.get("report_requirements")
    constraints = user_input.get("constraints")
    rules_source = user_input.get("rules_source", "assets/public/business-rules.md")
    rules_path = rules_source.split(" (", 1)[0] if isinstance(rules_source, str) else "assets/public/business-rules.md"
    target_url = user_input.get("target_url", "http://127.0.0.1:4173")
    lines = [
        "# Web application testing task",
        "",
        f"Case ID: {task_id}",
        f"Dataset ID: {dataset_id}",
        f"Pinned webapp-testing Skill commit: {skill_commit}",
        "",
        "## Task",
        task,
        "",
        "## Public inputs",
        f"Target application URL: `{target_url}`.",
        f"Read the public business rules at `{rules_path}` and use them as the authority for expected application behavior.",
        "The application fixture is available at `fixtures/workboard/` for startup and selector context only. Do not replace real browser testing with source inspection.",
        "",
        "## Execution requirements",
        "Use the pinned webapp-testing Skill instructions. Use Python Playwright sync API and headless Chromium.",
        "Wait for observable page readiness. Do not use a fixed sleep as the only readiness check.",
        "Save the report, evidence index, Playwright scripts, screenshots, browser/page logs, and relevant network evidence under `artifacts/" + task_id + "/`.",
        "Do not modify application source files. Do not access external websites, external services, production data, hidden answers, or evaluator internals.",
        "Do not read evaluation labels or runtime configuration that are not part of the public task. Do not infer them from application behavior.",
        "Keep all commands fixed and trusted. Do not interpolate task text, page content, or other untrusted values into shell commands.",
        "Report only what you actually observed. Mark insufficiently evidenced conclusions as UNKNOWN.",
    ]
    if isinstance(constraints, list) and constraints:
        lines += ["", "## Task-specific constraints"]
        lines += [f"- {item}" for item in constraints if isinstance(item, str)]
    if isinstance(report_requirements, dict) and report_requirements:
        lines += ["", "## Report requirements"]
        lines.append(f"Format: {report_requirements.get('format', 'Markdown report + JSON evidence index')}")
        lines.append(f"Language: {report_requirements.get('language', 'Chinese')}")
        required = report_requirements.get("must_include", [])
        if isinstance(required, list):
            for item in required:
                if not isinstance(item, str):
                    continue
                # Fixture profile/mutation labels are runner-only and must not be
                # disclosed to the Skill under test. Preserve the safe part of the
                # reporting requirement without passing those labels through.
                lowered = item.casefold()
                if "fixture profile" in lowered or "fixture mutations" in lowered or "mutation label" in lowered:
                    lines.append("- Environment: application URL, server start method, and health/readiness evidence.")
                else:
                    lines.append(f"- {item}")
    lines += ["", "Do not claim that a test passed without concrete browser evidence."]
    return "\n".join(lines) + "\n"


def capture_runtime_versions() -> dict[str, str | None]:
    def version(command: list[str]) -> str | None:
        try:
            completed = subprocess.run(command, check=True, text=True, capture_output=True, timeout=15)
            return (completed.stdout or completed.stderr).strip().splitlines()[0]
        except Exception:
            return None

    try:
        from importlib.metadata import version as package_version
        playwright_version = package_version("playwright")
    except Exception:
        playwright_version = None
    chromium_version = None
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as playwright:
            browser_binary = playwright.chromium.executable_path
            chromium_version = version([browser_binary, "--version"])
    except Exception:
        chromium_version = None
    return {
        "python": sys.version.split()[0],
        "node": version(["node", "--version"]),
        "dsh": version(["dsh", "--version"]),
        "playwright": playwright_version,
        "chromium": chromium_version,
    }


def redact_secret(root_paths: list[Path], secret: str) -> list[str]:
    if not secret:
        return []
    needle = secret.encode("utf-8")
    redacted: list[str] = []
    for root in root_paths:
        if not root.exists():
            continue
        candidates = [root] if root.is_file() else [p for p in root.rglob("*") if p.is_file()]
        for path in candidates:
            try:
                raw = path.read_bytes()
            except OSError:
                continue
            if needle in raw:
                path.write_bytes(raw.replace(needle, b"[REDACTED_SECRET]"))
                redacted.append(str(path))
    return redacted


def copy_agent_outputs(workspace: Path, case_output: Path, case_id: str) -> list[str]:
    copied: list[str] = []
    agent_artifacts = workspace / "artifacts"
    if agent_artifacts.is_dir():
        destination = case_output / "agent-artifacts"
        shutil.copytree(agent_artifacts, destination, dirs_exist_ok=True)
        copied.extend(p.relative_to(case_output).as_posix() for p in destination.rglob("*") if p.is_file())
    scripts = [
        path for path in workspace.rglob("*.py")
        if path.is_file()
        and ".dsh" not in path.parts
        and "fixtures" not in path.parts
        and "assets" not in path.parts
        and "__pycache__" not in path.parts
    ]
    if scripts:
        destination = case_output / "workspace-scripts"
        destination.mkdir(parents=True, exist_ok=True)
        for path in scripts:
            relative = path.relative_to(workspace)
            target = destination / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
            copied.append(target.relative_to(case_output).as_posix())
    return sorted(set(copied))


def execute_case(args: argparse.Namespace) -> int:
    dataset_path = Path(args.dataset).resolve()
    fixture_source = Path(args.fixture_source).resolve()
    public_assets = Path(args.public_assets).resolve()
    skill_source = Path(args.skill_source).resolve()
    work_root = Path(args.work_root).resolve()
    output_root = Path(args.output_dir).resolve()
    case_output = output_root / args.case_id
    workspace = work_root / args.case_id

    for required in (dataset_path, fixture_source / "server.py", public_assets / "business-rules.md", skill_source / "SKILL.md"):
        if not required.exists():
            raise FileNotFoundError(f"required input missing: {required}")
    if case_output.exists():
        shutil.rmtree(case_output)
    if workspace.exists():
        shutil.rmtree(workspace)
    case_output.mkdir(parents=True, exist_ok=True)
    workspace.mkdir(parents=True, exist_ok=True)

    cases: list[dict[str, Any]] = []
    for line_no, line in enumerate(dataset_path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        item = json.loads(line)
        if item.get("case_id") == args.case_id:
            cases.append(item)
    if len(cases) != 1:
        raise ValueError(f"expected exactly one {args.case_id} in {dataset_path}, found {len(cases)}")
    case = cases[0]
    validate_case(case, args.dataset_id)

    user_input = case["user_input"]
    environment = case["execution_requirements"]["environment"]
    profile = environment["fixture_profile"]
    mutations = environment.get("fixture_mutations", [])
    start_state = environment.get("server_state_at_start", "running")
    base_url, host, port = require_local_target(user_input, environment)
    if port != EXPECTED_PORT:
        raise ValueError(f"port must be {EXPECTED_PORT}")

    shutil.copytree(public_assets, workspace / "assets" / "public", dirs_exist_ok=True)
    shutil.copytree(fixture_source, workspace / "fixtures" / "workboard", dirs_exist_ok=True)
    shutil.copytree(skill_source, workspace / ".dsh" / "skills" / "webapp-testing", dirs_exist_ok=True)
    fixture_workspace = workspace / "fixtures" / "workboard"
    fixture_before = tree_sha256(fixture_workspace)

    artifacts_dir = workspace / "artifacts" / args.case_id
    artifacts_dir.mkdir(parents=True, exist_ok=True)
    prompt = build_task_prompt(case, args.skill_commit)
    (case_output / "task-prompt.md").write_text(prompt, encoding="utf-8")
    (workspace / "TASK.md").write_text(prompt, encoding="utf-8")

    dsh_events_path = case_output / "dsh-events.jsonl"
    dsh_stderr_path = case_output / "dsh-stderr.log"
    server_log_path = case_output / "server.log"
    server_audit_path = case_output / "server-audit.jsonl"
    reset_path = case_output / "reset-evidence.json"
    process: subprocess.Popen | None = None
    server_log_handle = server_log_path.open("w", encoding="utf-8")
    started_at = utc_now()
    pre_state = None
    post_state = None
    app_health_before = False
    app_health_after_skill = False
    app_port_after_skill = False
    app_port_after_cleanup = False
    cleanup_errors: list[str] = []
    runner_error = None
    server_lifecycle_ok = False
    timed_out = False
    dsh_exit_code = None
    trace_summary: dict[str, Any] = {}

    secret = os.environ.get("DEEPSEEK_API_KEY", "")
    if not secret:
        server_log_handle.close()
        raise RuntimeError("DEEPSEEK_API_KEY is missing")

    try:
        if port_is_open(host, port):
            raise RuntimeError(f"port {port} is already occupied before case start")

        if start_state == "running":
            server_env = os.environ.copy()
            server_env.update({
                "APP_HOST": host,
                "APP_PORT": str(port),
                "APP_PROFILE": profile,
                "APP_MUTATIONS": ",".join(mutations),
                "APP_AUDIT_LOG": str(server_audit_path),
            })
            server_env.pop("DEEPSEEK_API_KEY", None)
            process = subprocess.Popen(
                [sys.executable, "server.py"],
                cwd=fixture_workspace,
                env=server_env,
                stdout=server_log_handle,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            wait_for_health(base_url)
            app_health_before = True
            reset_status, reset_payload = http_json(base_url + "/api/reset", "POST", {})
            if reset_status != 200:
                raise RuntimeError(f"reset failed: HTTP {reset_status}")
            state_status, pre_state = http_json(base_url + "/api/tasks")
            if state_status != 200:
                raise RuntimeError(f"initial state read failed: HTTP {state_status}")
            reset_path.write_text(json.dumps({
                "health_check": "PASS",
                "reset_status": reset_status,
                "reset_payload": reset_payload,
                "initial_state_status": state_status,
                "initial_state": pre_state,
                "captured_at": utc_now(),
            }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        else:
            if port_is_open(host, port):
                raise RuntimeError("case requires a stopped app, but the port is already open")
            reset_path.write_text(json.dumps({
                "initial_state": "server_stopped_before_skill_invocation",
                "captured_at": utc_now(),
            }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

        dsh_env = os.environ.copy()
        dsh_env.update({
            "DSH_TELEMETRY_MODE": "DISABLED",
            "DSH_TELEMETRY_DISABLED": "1",
        })
        # Keep fixture labels out of the DSH/Skill process environment.
        for name in ("APP_PROFILE", "APP_MUTATIONS", "APP_AUDIT_LOG", "APP_PORT", "APP_HOST"):
            dsh_env.pop(name, None)
        with dsh_events_path.open("w", encoding="utf-8") as events_handle, dsh_stderr_path.open("w", encoding="utf-8") as stderr_handle:
            process_dsh = subprocess.Popen(
                ["dsh", "--profile", "headless", "--json", "--permission-mode", "workspace-write", "-"],
                cwd=workspace,
                env=dsh_env,
                stdin=subprocess.PIPE,
                stdout=events_handle,
                stderr=stderr_handle,
                text=True,
                start_new_session=True,
            )
            try:
                process_dsh.communicate(prompt, timeout=args.case_timeout)
                dsh_exit_code = process_dsh.returncode
            except subprocess.TimeoutExpired:
                timed_out = True
                dsh_exit_code = 124
                stop_process_group(process_dsh)

        trace_summary = parse_dsh_events(dsh_events_path)
        app_port_after_skill = port_is_open(host, port)
        server_lifecycle_ok = (start_state == "running" and app_port_after_skill) or (start_state == "stopped" and not app_port_after_skill)
        if not server_lifecycle_ok:
            cleanup_errors.append(f"Skill did not preserve required server lifecycle for initial state {start_state}")
        if app_port_after_skill:
            try:
                wait_for_health(base_url, timeout_seconds=5)
                app_health_after_skill = True
                state_status, post_state = http_json(base_url + "/api/tasks")
                if state_status != 200:
                    cleanup_errors.append(f"post-state HTTP {state_status}")
            except Exception as exc:
                cleanup_errors.append(f"post-state capture: {type(exc).__name__}: {exc}")
    except Exception as exc:
        runner_error = f"{type(exc).__name__}: {exc}"
    finally:
        # Reset app data before shutdown whenever the runner started the server.
        if process is not None and process.poll() is None:
            try:
                if port_is_open(host, port):
                    http_json(base_url + "/api/reset", "POST", {})
            except Exception as exc:
                cleanup_errors.append(f"final reset: {type(exc).__name__}: {exc}")
            stop_process_group(process)
        if port_is_open(host, port):
            if not force_close_test_port(port):
                cleanup_errors.append(f"could not release test port {port}")
        app_port_after_cleanup = port_is_open(host, port)
        server_log_handle.close()

    trace_summary = trace_summary or parse_dsh_events(dsh_events_path)
    fixture_after = tree_sha256(fixture_workspace)
    copied_files = copy_agent_outputs(workspace, case_output, args.case_id)
    # Keep a compact copy of scripts and the workspace-side artifacts, but never copy
    # private DSH configuration or runner-only metadata into the Skill workspace.
    runtime_versions = capture_runtime_versions()
    redacted_files = redact_secret([case_output, workspace], secret)

    skill_invocation_ok = (
        dsh_exit_code == 0
        and not timed_out
        and trace_summary.get("webapp_testing_skill_calls", 0) > 0
        and trace_summary.get("completed_webapp_testing_skill_calls", 0) > 0
        and trace_summary.get("final_reason") == "completed"
    )
    cleanup_ok = not app_port_after_cleanup and not cleanup_errors
    fixture_unchanged = fixture_before == fixture_after
    runner_status = "PASS" if skill_invocation_ok and cleanup_ok and fixture_unchanged and not redacted_files and not runner_error else "BLOCKED"

    result = {
        "runner_version": RUNNER_VERSION,
        "case_id": args.case_id,
        "dataset_id": args.dataset_id,
        "status": runner_status,
        "scope": "Skill load/invocation/completion and harness cleanup only; not grading or Oracle adjudication",
        "started_at_utc": started_at,
        "finished_at_utc": utc_now(),
        "skill_commit": args.skill_commit,
        "fixture_profile_runner_only": profile,
        "fixture_mutations_runner_only": mutations,
        "server_state_at_start_runner_only": start_state,
        "app_health_before_skill": app_health_before,
        "app_port_open_after_skill": app_port_after_skill,
        "app_health_after_skill": app_health_after_skill,
        "app_port_open_after_cleanup": app_port_after_cleanup,
        "initial_state_runner_only": pre_state,
        "post_state_runner_only": post_state,
        "dsh_exit_code": dsh_exit_code,
        "timed_out": timed_out,
        "runner_error": runner_error,
        "cleanup_errors": cleanup_errors,
        "skill_invocation_ok": skill_invocation_ok,
        "cleanup_ok": cleanup_ok,
        "server_lifecycle_ok": server_lifecycle_ok,
        "fixture_tree_sha256_before": fixture_before,
        "fixture_tree_sha256_after": fixture_after,
        "fixture_modified_by_skill": not fixture_unchanged,
        "trace": trace_summary,
        "runtime_versions": runtime_versions,
        "credential_leak_detected_before_redaction": bool(redacted_files),
        "redacted_files": redacted_files,
        "agent_artifacts_copied": copied_files,
    }
    (case_output / "runner-result.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({
        "case_id": args.case_id,
        "dataset_id": args.dataset_id,
        "status": runner_status,
        "skill_invocation_ok": skill_invocation_ok,
        "dsh_exit_code": dsh_exit_code,
        "trace": trace_summary,
        "cleanup_ok": cleanup_ok,
        "runner_error": runner_error,
    }, ensure_ascii=False), flush=True)
    return 0 if runner_status == "PASS" else 1


def self_test() -> int:
    sample = [
        {"type": "tool_call", "tool": "skill", "callId": "c1", "input": {"name": "webapp-testing"}},
        {"type": "tool_result", "callId": "c1", "status": "completed"},
        {"type": "final", "reason": {"kind": "completed"}},
    ]
    temporary = Path("/tmp/webapp-testing-runner-self-test.jsonl")
    temporary.write_text("\n".join(json.dumps(x) for x in sample) + "\n", encoding="utf-8")
    parsed = parse_dsh_events(temporary)
    temporary.unlink(missing_ok=True)
    assert parsed["webapp_testing_skill_calls"] == 1
    assert parsed["completed_webapp_testing_skill_calls"] == 1
    assert parsed["final_reason"] == "completed"
    case = {
        "case_id": "WBT-CONF-001",
        "dataset_id": "WBT-CONF-001",
        "user_input": {
            "task": "Use a browser",
            "target_url": "http://127.0.0.1:4173",
            "rules_source": "assets/public/business-rules.md (v0.1.0, SYNTHETIC)",
            "report_requirements": {"must_include": ["fixture profile/mutations", "Screenshots and logs"]},
        },
        "execution_requirements": {"environment": {"fixture_profile": "clean", "fixture_mutations": [], "server_state_at_start": "running"}},
    }
    validate_case(case, "WBT-CONF-001")
    prompt = build_task_prompt(case, "test-commit")
    assert "grading" not in prompt.casefold()
    assert "expected_behavior" not in prompt.casefold()
    assert "fixture_profile" not in prompt.casefold()
    assert "fixture profile/mutations" not in prompt.casefold()
    assert "assets/public/business-rules.md (v0.1.0" not in prompt
    print(json.dumps({"self_test": "PASS", "trace_parser": "PASS", "case_validation": "PASS", "prompt_isolation": "PASS"}, indent=2))
    return 0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", required=False)
    parser.add_argument("--dataset-id", required=False)
    parser.add_argument("--case-id", required=False)
    parser.add_argument("--fixture-source", required=False)
    parser.add_argument("--public-assets", required=False)
    parser.add_argument("--skill-source", required=False)
    parser.add_argument("--work-root", required=False)
    parser.add_argument("--output-dir", required=False)
    parser.add_argument("--skill-commit", required=False)
    parser.add_argument("--case-timeout", type=int, default=900)
    parser.add_argument("--self-test", action="store_true")
    parsed = parser.parse_args()
    if not parsed.self_test:
        required = (
            "dataset", "dataset_id", "case_id", "fixture_source", "public_assets",
            "skill_source", "work_root", "output_dir", "skill_commit",
        )
        missing = [name for name in required if not getattr(parsed, name)]
        if missing:
            parser.error("missing required arguments: " + ", ".join("--" + name.replace("_", "-") for name in missing))
    if parsed.case_timeout < 60:
        parser.error("--case-timeout must be at least 60 seconds")
    return parsed


if __name__ == "__main__":
    cli_args = parse_args()
    if cli_args.self_test:
        raise SystemExit(self_test())
    raise SystemExit(execute_case(cli_args))
